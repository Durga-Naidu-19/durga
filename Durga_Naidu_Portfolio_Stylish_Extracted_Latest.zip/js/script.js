document.addEventListener("DOMContentLoaded", function () {
    console.log("DURGA NAIDU's Portfolio Loaded Successfully!");
});
